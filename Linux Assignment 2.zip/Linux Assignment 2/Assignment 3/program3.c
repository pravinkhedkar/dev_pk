#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main()
{
int status,i;
pid_t pid;
printf("The main Process ID is%d\n",getpid() );

for(i=0;i<3;i++)
{
	if(fork()==0){

pid=getpid();

		printf("Child (%d): %d\n", i + 1, pid);
		printf("Parent (%d): %d\n", i + 1, getppid());



		kill(getpid(), SIGKILL);
	}
}


pid=wait(&status);



	return 0;
}
