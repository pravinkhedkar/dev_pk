#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main()
{
int status,i,no;
pid_t pid;
printf("The main Process ID is%d\n",getpid() );

	for(i=0;i<2;i++)
	{
		no = fork();

	 	if (no > 0)
	 			printf("in parent process");
		else if(no == 0){

	sleep(30);
printf("in child process");
			printf("Child (%d): %d\n", i + 1, pid);
			printf("Parent (%d): %d\n", i + 1, getppid());



			//kill(getpid(), SIGKILL);
		}
	}



	return 0;
}
