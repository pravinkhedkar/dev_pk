#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>


int main()
{
int status,i,no,fd1,fd2,fd3,count1=0,count2=0;
pid_t pid;
char buf[256];
char count[5];
printf("The main Process ID is%d\n",getpid());

fd3=open("count.txt",O_WRONLY);
if(fd3==-1){
	printf("unable to open file");
}
	pid=fork();
	if(pid==0){
		fd1=open("demo.txt",O_RDONLY);
		if(fd2 ==-1){
			printf("unable to open file");
		}
		while (read(fd1,buf,256)!=0){
			//printf("%d\n",strlen(buf));
		}
		for ( i = 0; i < strlen(buf)-1; i++) {
			if(buf[i]>='A' && buf[i]<='Z'){
			//printf("%c\n",buf[i]);
			count1++;
		}
				}






	}
	else{
		no=fork();
		if(no==0){
			fd2=open("Hello.txt",O_RDONLY);
			if(fd2==-1){
				printf("unable to open file");
			}
while (read(fd2,buf,256)!=0){
	//printf("%d\n",strlen(buf));
}
for ( i = 0; i < strlen(buf)-1; i++) {
	if(buf[i]>='A' && buf[i]<='Z'){
	//printf("%c\n",buf[i]);
	count2++;
}
		}
//itoa(count2,count,10);
//printf("%d\n",count2);
snprintf(count, sizeof(count), "%d : %d", count2,count1);
  printf ("count2: %s\n",count);
	write(fd3,count,sizeof count);
//printf("%d\n",count2);


	}
	//printf("%d %d\n",count1,count2 );

}

	return 0;
}
