#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main()
{
int status;
pid_t pid;

	if(fork() == 0)
	{
		printf("Before process 1 creation\n");

		printf("Sleep complete\n");
	}

	else
	{
		printf("Inside Parent process\n");
		pid = wait(&status);

		printf("Child process having PID %d terminates with exit status %d\n",pid,status);
	printf("Execution of parent process completed after waiting to kill the Child\n");
	}

	return 0;
}
