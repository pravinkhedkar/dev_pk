#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include<fcntl.h>
#include <dirent.h>
#include<string.h>
#include <sys/stat.h>


int main(int argc,char * argv)
{
int status,i,no,fd;
char fname[100];
struct stat buf;
DIR *dir;
struct dirent *dir_entry;
pid_t pid;
printf("The main Process ID is%d\n",getpid() );
pid=fork();
	if(pid==0)
	{
		fd=creat("demo2.txt",0x777);
		if(fd ==-1){
			printf("unable to create the file\n" );

		}
		char dirname[]="/home/pravin/Desktop/";
		if ((dir = opendir(dirname)) == NULL)
		{
			printf("Unable to open specified directory\n");
			return -1;
		}
		while ((dir_entry = readdir(dir)) != NULL){
			//printf("%s\n",dir_entry->d_name );
			strcpy(fname,dir_entry->d_name);
			printf("%s\n",fname );
			write(fd,fname,strlen(fname));
		}

	}
	else
	{
printf("In Parent");
	}



	return 0;
}
