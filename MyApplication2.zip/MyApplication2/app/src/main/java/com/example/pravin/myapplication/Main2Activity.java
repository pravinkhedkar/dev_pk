package com.example.pravin.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity  implements  Constants{

    String MySharedPref ="MY_SHARED_PREF";
    String lstrUserName;
    private TextView txtUserName;
    private Button  LogOutButton;
    private Context context;
    private Intent intent;
    private SharedPreferences sharedPreferences;


   // private Button LogOutButton;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //String restoredText = null;
        txtUserName=findViewById(R.id.textUserName);
       LogOutButton=findViewById(R.id.LogOut);
        try {

            SharedPreferences prefs = getSharedPreferences(MySharedPref, MODE_PRIVATE);

            lstrUserName = prefs.getString("NAME", "UNDEFINED");
            txtUserName.setText(lstrUserName);
            SharedPreferences.Editor editor = getSharedPreferences(MySharedPref, MODE_PRIVATE).edit();

            editor.putString("ENDSESSION","N");

            editor.apply();

        }catch (Exception e){
            e.printStackTrace();
        }

LogOut();

    }
    public void ClearSession()
    {
        sharedPreferences =getSharedPreferences(MySharedPref,MODE_PRIVATE);
        SharedPreferences.Editor editor = getSharedPreferences(MySharedPref, MODE_PRIVATE).edit();
        if(sharedPreferences.contains("NAME")){
            editor.remove("NAME");
            editor.putString("ENDSESSION","Y");
            editor.apply();
        }

       intent=new Intent(this,MainActivity.class);
        startActivity(intent);


    }
    public void LogOut()
    {
      LogOutButton.setOnClickListener(new View.OnClickListener()
     {
                                          @Override
                                          public void onClick(View v)
     {
                            AddActionDialogForLogoutWarning();

     }
     });
    }

    public void AddActionDialogForLogoutWarning()
    {
        context=this;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Do you want to Logout");
        builder.setPositiveButton("Logout", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                ClearSession();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }


    @Override
    public void onBackPressed()
    {
String sstr="";
        AddActionDialogForLogoutWarning();
    }




}
