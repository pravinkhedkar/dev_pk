package com.example.pravin.myapplication;

/**
 * Created by pravin on 03-Feb-18.
 */

public interface Constants {

      interface  demo {

           String str="Test";

     }
     abstract  class  demo2{
         static String str="";

     }

     String Demo="";
}


